import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/constants/app_config.dart';

enum CallType { audio, video }

enum CallStatus {
  ringing,
  accepted,
  rejected,
  busy,
  missed,
  cancelled,
  ended,
  failed,
  disconnected,
}

enum CallPhase {
  idle,
  calling,
  ringing,
  connected,
  inCall,
  ended,
  rejected,
  missed,
  cancelled,
  busy,
  failed,
  disconnected,
}

class CallModel {
  const CallModel({
    required this.id,
    required this.callerId,
    required this.calleeId,
    required this.callerName,
    required this.calleeName,
    required this.type,
    required this.status,
    required this.channelName,
    required this.participants,
    this.callerPhoto,
    this.calleePhoto,
    this.createdAt,
    this.answeredAt,
    this.endedAt,
    this.aliveAt,
    this.durationSeconds = 0,
  });

  final String id;
  final String callerId;
  final String calleeId;
  final String callerName;
  final String calleeName;
  final String? callerPhoto;
  final String? calleePhoto;
  final CallType type;
  final CallStatus status;
  final String channelName;
  final List<String> participants;
  final DateTime? createdAt;
  final DateTime? answeredAt;
  final DateTime? endedAt;
  final DateTime? aliveAt;
  final int durationSeconds;

  bool get isVideo => type == CallType.video;
  bool get isMissed => status == CallStatus.missed;
  bool isIncomingFor(String uid) => calleeId == uid;
  bool isOutgoingFor(String uid) => callerId == uid;

  String peerName(String uid) => uid == callerId ? calleeName : callerName;
  String? peerPhoto(String uid) => uid == callerId ? calleePhoto : callerPhoto;
  String peerId(String uid) => uid == callerId ? calleeId : callerId;

  static bool _isFresh(DateTime? at, Duration maxAge) {
    if (at == null) return true;
    return DateTime.now().difference(at) < maxAge;
  }

  /// Ringing older than the ring timeout, or accepted without a recent
  /// heartbeat, must not make the user look busy.
  bool get isGenuinelyActive {
    switch (status) {
      case CallStatus.ringing:
        return _isFresh(createdAt, AppConfig.callRingTimeout);
      case CallStatus.accepted:
        return _isFresh(
          aliveAt ?? answeredAt ?? createdAt,
          AppConfig.callAliveTimeout,
        );
      default:
        return false;
    }
  }

  CallModel copyWith({
    CallStatus? status,
    DateTime? answeredAt,
    DateTime? endedAt,
    DateTime? aliveAt,
    int? durationSeconds,
  }) {
    return CallModel(
      id: id,
      callerId: callerId,
      calleeId: calleeId,
      callerName: callerName,
      calleeName: calleeName,
      callerPhoto: callerPhoto,
      calleePhoto: calleePhoto,
      type: type,
      status: status ?? this.status,
      channelName: channelName,
      participants: participants,
      createdAt: createdAt,
      answeredAt: answeredAt ?? this.answeredAt,
      endedAt: endedAt ?? this.endedAt,
      aliveAt: aliveAt ?? this.aliveAt,
      durationSeconds: durationSeconds ?? this.durationSeconds,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'callerId': callerId,
      'calleeId': calleeId,
      'callerName': callerName,
      'calleeName': calleeName,
      'callerPhoto': callerPhoto,
      'calleePhoto': calleePhoto,
      'type': type.name,
      'status': status.name,
      'channelName': channelName,
      'participants': participants,
      'createdAt': createdAt == null
          ? FieldValue.serverTimestamp()
          : Timestamp.fromDate(createdAt!),
      'answeredAt': answeredAt == null ? null : Timestamp.fromDate(answeredAt!),
      'endedAt': endedAt == null ? null : Timestamp.fromDate(endedAt!),
      'aliveAt': FieldValue.serverTimestamp(),
      'durationSeconds': durationSeconds,
    };
  }

  static CallType _type(String? raw) =>
      raw == 'video' ? CallType.video : CallType.audio;

  static CallStatus _status(String? raw) {
    return CallStatus.values.firstWhere(
      (s) => s.name == raw,
      orElse: () => CallStatus.ringing,
    );
  }

  factory CallModel.fromMap(Map<String, dynamic> map, String id) {
    return CallModel(
      id: map['id'] as String? ?? id,
      callerId: map['callerId'] as String? ?? '',
      calleeId: map['calleeId'] as String? ?? '',
      callerName: map['callerName'] as String? ?? 'Unknown',
      calleeName: map['calleeName'] as String? ?? 'Unknown',
      callerPhoto: map['callerPhoto'] as String?,
      calleePhoto: map['calleePhoto'] as String?,
      type: _type(map['type'] as String?),
      status: _status(map['status'] as String?),
      channelName: map['channelName'] as String? ?? id,
      participants: List<String>.from(map['participants'] as List? ?? const []),
      createdAt: (map['createdAt'] as Timestamp?)?.toDate(),
      answeredAt: (map['answeredAt'] as Timestamp?)?.toDate(),
      endedAt: (map['endedAt'] as Timestamp?)?.toDate(),
      aliveAt: (map['aliveAt'] as Timestamp?)?.toDate(),
      durationSeconds: map['durationSeconds'] as int? ?? 0,
    );
  }

  factory CallModel.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    return CallModel.fromMap(doc.data() ?? {}, doc.id);
  }
}
