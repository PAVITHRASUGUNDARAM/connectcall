import 'dart:async';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:agora_token_generator/agora_token_generator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';

import '../core/constants/app_config.dart';
import '../core/utils/agora_uid.dart';
import '../models/call_model.dart';
import '../models/user_model.dart';

enum NetworkQuality { unknown, good, fair, poor }

class CallingService {
  CallingService(this._db);

  final FirebaseFirestore _db;
  final _uuid = const Uuid();

  RtcEngine? _engine;
  StreamController<int>? _remoteUid;
  StreamController<NetworkQuality>? _quality;
  StreamController<String>? _engineErrors;
  Completer<void>? _joinWaiter;
  int? lastRemoteUid;

  CollectionReference<Map<String, dynamic>> get _calls =>
      _db.collection(FirestorePaths.calls);

  Stream<int> get remoteUid$ =>
      _remoteUid?.stream ?? const Stream.empty();

  Stream<NetworkQuality> get quality$ =>
      _quality?.stream ?? const Stream.empty();

  Stream<String> get engineErrors$ =>
      _engineErrors?.stream ?? const Stream.empty();

  RtcEngine? get engine => _engine;

  Future<RtcEngine> ensureEngine({required bool video}) async {
    if (!AppConfig.isAgoraConfigured) {
      throw StateError(
        'Agora App ID is missing. Set AGORA_APP_ID via --dart-define.',
      );
    }
    if (_engine != null) {
      if (video) {
        await _engine!.enableVideo();
        await _engine!.startPreview();
      } else {
        await _engine!.stopPreview();
        await _engine!.disableVideo();
      }
      return _engine!;
    }

    _remoteUid = StreamController<int>.broadcast();
    _quality = StreamController<NetworkQuality>.broadcast();
    _engineErrors = StreamController<String>.broadcast();
    lastRemoteUid = null;

    final engine = createAgoraRtcEngine();
    await engine.initialize(
      RtcEngineContext(
        appId: AppConfig.agoraAppId,
        channelProfile: ChannelProfileType.channelProfileCommunication,
      ),
    );
    engine.registerEventHandler(
      RtcEngineEventHandler(
        onJoinChannelSuccess: (connection, elapsed) {
          final waiter = _joinWaiter;
          if (waiter != null && !waiter.isCompleted) {
            waiter.complete();
          }
        },
        onUserJoined: (connection, remoteUid, elapsed) {
          lastRemoteUid = remoteUid;
          _remoteUid?.add(remoteUid);
        },
        onUserOffline: (connection, remoteUid, reason) {
          if (lastRemoteUid == remoteUid) {
            lastRemoteUid = null;
          }
          _remoteUid?.add(0);
        },
        onConnectionStateChanged: (connection, state, reason) {
          if (state == ConnectionStateType.connectionStateFailed) {
            _failJoin('Media connection failed');
          }
        },
        onError: (err, msg) {
          if (!_isFatalAgoraError(err)) return;
          final text = msg.isNotEmpty ? msg : err.toString();
          _failJoin(text);
        },
        onNetworkQuality: (connection, uid, txQuality, rxQuality) {
          _quality?.add(_mapQuality(txQuality, rxQuality));
        },
      ),
    );
    await engine.enableAudio();
    if (video) {
      await engine.enableVideo();
      await engine.startPreview();
    }
    await engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);
    _engine = engine;
    return engine;
  }

  Future<void> joinChannel({
    required String channelName,
    required String firebaseUid,
    required bool video,
  }) async {
    final engine = await ensureEngine(video: video);
    final uid = agoraUidFrom(firebaseUid);
    final token = _rtcToken(channelName, uid);

    _joinWaiter = Completer<void>();
    lastRemoteUid = null;

    await engine.joinChannel(
      token: token,
      channelId: channelName,
      uid: uid,
      options: ChannelMediaOptions(
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
        channelProfile: ChannelProfileType.channelProfileCommunication,
        publishMicrophoneTrack: true,
        publishCameraTrack: video,
        autoSubscribeAudio: true,
        autoSubscribeVideo: video,
      ),
    );

    try {
      await _joinWaiter!.future.timeout(const Duration(seconds: 20));
    } on TimeoutException {
      throw StateError(
        'Could not join the media channel. Check Agora App ID, App Certificate, and network.',
      );
    } finally {
      _joinWaiter = null;
    }
  }

  String _rtcToken(String channelName, int uid) {
    if (AppConfig.agoraToken.isNotEmpty) return AppConfig.agoraToken;
    if (AppConfig.agoraAppCertificate.isEmpty) return '';
    return RtcTokenBuilder.buildTokenWithUid(
      appId: AppConfig.agoraAppId,
      appCertificate: AppConfig.agoraAppCertificate,
      channelName: channelName,
      uid: uid,
      tokenExpireSeconds: 3600,
    );
  }

  void _failJoin(String message) {
    final waiter = _joinWaiter;
    if (waiter != null && !waiter.isCompleted) {
      waiter.completeError(StateError(message));
    }
    _engineErrors?.add(message);
  }

  static bool _isFatalAgoraError(ErrorCodeType err) {
    switch (err) {
      case ErrorCodeType.errInvalidAppId:
      case ErrorCodeType.errInvalidToken:
      case ErrorCodeType.errTokenExpired:
      case ErrorCodeType.errInvalidChannelName:
        return true;
      default:
        return false;
    }
  }

  Future<void> leaveChannel() async {
    await _engine?.leaveChannel();
    await _engine?.stopPreview();
    lastRemoteUid = null;
  }

  Future<void> muteLocalAudio(bool muted) =>
      _engine?.muteLocalAudioStream(muted) ?? Future.value();

  Future<void> setSpeakerphone(bool on) =>
      _engine?.setEnableSpeakerphone(on) ?? Future.value();

  Future<void> muteLocalVideo(bool muted) async {
    await _engine?.muteLocalVideoStream(muted);
    await _engine?.enableLocalVideo(!muted);
  }

  Future<void> switchCamera() => _engine?.switchCamera() ?? Future.value();

  Future<CallModel> createOutgoingCall({
    required UserModel caller,
    required UserModel callee,
    required CallType type,
  }) async {
    final busy = await _hasActiveCall(callee.uid);
    final id = _uuid.v4();
    final call = CallModel(
      id: id,
      callerId: caller.uid,
      calleeId: callee.uid,
      callerName: caller.name,
      calleeName: callee.name,
      callerPhoto: caller.photoUrl,
      calleePhoto: callee.photoUrl,
      type: type,
      status: busy ? CallStatus.busy : CallStatus.ringing,
      channelName: id.replaceAll('-', ''),
      participants: [caller.uid, callee.uid],
      createdAt: DateTime.now(),
    );
    await _calls.doc(id).set(call.toMap());
    return call;
  }

  Future<bool> _hasActiveCall(String uid) async {
    final snap = await _calls
        .where('participants', arrayContains: uid)
        .limit(20)
        .get();

    var busy = false;

    for (final doc in snap.docs) {
      final call = CallModel.fromDoc(doc);

      if (call.status != CallStatus.ringing &&
          call.status != CallStatus.accepted) {
        continue;
      }

      if (call.isGenuinelyActive) {
        busy = true;
      } else {
        await _finalize(
          call.id,
          call.status == CallStatus.ringing
              ? CallStatus.missed
              : CallStatus.failed,
        );
      }
    }

    return busy;
  }

  Future<void> reapStaleCalls(String uid) async {
    await _hasActiveCall(uid);
  }

  Future<void> touchAlive(String callId) {
    return _calls.doc(callId).set({
      'aliveAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Stream<CallModel?> watchCall(String callId) {
    return _calls.doc(callId).snapshots().map((doc) {
      if (!doc.exists) return null;
      return CallModel.fromDoc(doc);
    });
  }

  Stream<CallModel?> watchIncoming(String uid) {
    // Query only by calleeId so this does not require a Firestore
    // composite index on (calleeId, status).
    return _calls
        .where('calleeId', isEqualTo: uid)
        .snapshots()
        .map((snap) {
      final docs = snap.docs
          .where(
            (doc) => doc.data()['status'] == CallStatus.ringing.name,
          )
          .toList();

      if (docs.isEmpty) return null;

      docs.sort((a, b) {
        final aTime = a.data()['createdAt'] as Timestamp?;
        final bTime = b.data()['createdAt'] as Timestamp?;

        return (bTime?.millisecondsSinceEpoch ?? 0)
            .compareTo(aTime?.millisecondsSinceEpoch ?? 0);
      });

      for (final doc in docs) {
        final call = CallModel.fromDoc(doc);

        if (call.isGenuinelyActive) {
          return call;
        }
      }

      return null;
    });
  }

  Stream<List<CallModel>> watchHistory(String uid) {
    return _calls
        .where('participants', arrayContains: uid)
        .snapshots()
        .map((snap) {
      final items = snap.docs.map(CallModel.fromDoc).toList()
        ..sort((a, b) {
          final aMs = a.createdAt?.millisecondsSinceEpoch ?? 0;
          final bMs = b.createdAt?.millisecondsSinceEpoch ?? 0;
          return bMs.compareTo(aMs);
        });
      return items
          .where(
            (c) =>
                c.status != CallStatus.ringing &&
                c.status != CallStatus.accepted,
          )
          .toList();
    });
  }

  Future<void> accept(String callId) {
    return _calls.doc(callId).set({
      'status': CallStatus.accepted.name,
      'answeredAt': FieldValue.serverTimestamp(),
      'aliveAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> reject(String callId) {
    return _finalize(callId, CallStatus.rejected);
  }

  Future<void> cancel(String callId) {
    return _finalize(callId, CallStatus.cancelled);
  }

  Future<void> markMissed(String callId) {
    return _finalize(callId, CallStatus.missed);
  }

  Future<void> markFailed(String callId) {
    return _finalize(callId, CallStatus.failed);
  }

  Future<void> endCall(String callId, {required int durationSeconds}) {
    return _finalize(
      callId,
      CallStatus.ended,
      durationSeconds: durationSeconds,
    );
  }

  Future<void> markDisconnected(String callId, {required int durationSeconds}) {
    return _finalize(
      callId,
      CallStatus.disconnected,
      durationSeconds: durationSeconds,
    );
  }

  Future<void> _finalize(
    String callId,
    CallStatus status, {
    int durationSeconds = 0,
  }) async {
    final ref = _calls.doc(callId);
    await _db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) return;
      final current = snap.data()?['status'] as String?;
      if (current != CallStatus.ringing.name &&
          current != CallStatus.accepted.name) {
        return;
      }
      tx.update(ref, {
        'status': status.name,
        'endedAt': FieldValue.serverTimestamp(),
        'durationSeconds': durationSeconds,
      });
    });
  }

  static NetworkQuality _mapQuality(
    QualityType tx,
    QualityType rx,
  ) {
    int rank(QualityType q) {
      switch (q) {
        case QualityType.qualityExcellent:
        case QualityType.qualityGood:
          return 3;
        case QualityType.qualityPoor:
        case QualityType.qualityBad:
          return 2;
        case QualityType.qualityVbad:
        case QualityType.qualityDown:
          return 1;
        default:
          return 0;
      }
    }

    final worst = rank(tx) < rank(rx) ? rank(tx) : rank(rx);
    if (worst >= 3) return NetworkQuality.good;
    if (worst == 2) return NetworkQuality.fair;
    if (worst == 1) return NetworkQuality.poor;
    return NetworkQuality.unknown;
  }

  Future<void> disposeEngine() async {
    await leaveChannel();
    await _engine?.release();
    _engine = null;
    await _remoteUid?.close();
    await _quality?.close();
    await _engineErrors?.close();
    _remoteUid = null;
    _quality = null;
    _engineErrors = null;
  }
}
